import { InsectCardData } from "../types/Insect";

export const sampleInsects: InsectCardData[] = [
  {
    id: "insect001",
    name: "Stag Beetle",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqE-bLwf4GI2_je3-Vgua_eVG93O6AwY6bOQ&s",
    habitat: "Deciduous forests and woodlands",
    behavior: "Nocturnal, males use mandibles in territorial fights",
    description:
      "Stag beetles are large insects with antler-like mandibles, often found in decaying wood.",
    rarity: "common",
  },
  {
    id: "insect002",
    name: "Argentine Ant",
    image: "https://example.com/images/argentine_ant.jpg",
    habitat: "Urban areas, gardens, and forests",
    behavior: "Highly social, forms large colonies and aggressive trails",
    description:
      "Argentine ants are small, invasive ants known for their massive colonies and adaptability.",
    rarity: "common",
  },
  {
    id: "insect003",
    name: "Brown-lipped Snail",
    image: "https://example.com/images/brown_lipped_snail.jpg",
    habitat: "Gardens, woodlands, and grasslands",
    behavior: "Herbivorous, active in damp conditions",
    description:
      "Brown-lipped snails are small mollusks with coiled shells, thriving in moist environments.",
    rarity: "common",
  },
  {
    id: "insect004",
    name: "Garden Cross Spider",
    image: "https://example.com/images/garden_cross_spider.jpg",
    habitat: "Gardens, forests, and meadows",
    behavior: "Web-building, captures prey in orb-shaped webs",
    description:
      "Garden cross spiders are orb-weavers with a distinctive cross pattern on their abdomen.",
    rarity: "common",
    seasonal: true,
  },
  {
    id: "insect005",
    name: "Colorado Potato Beetle",
    image: "https://example.com/images/colorado_potato_beetle.jpg",
    habitat: "Agricultural fields, especially potato crops",
    behavior: "Herbivorous, feeds on potato leaves",
    description:
      "Colorado potato beetles are pests with yellow and black stripes, damaging crops.",
    rarity: "common",
  },
  {
    id: "insect006",
    name: "Leafwing Butterfly",
    image: "https://example.com/images/leafwing_butterfly.jpg",
    habitat: "Tropical forests and rainforests",
    behavior: "Camouflages as a leaf when wings are closed",
    description:
      "Leafwing butterflies mimic dead leaves, blending into their surroundings to avoid predators.",
    rarity: "rare",
  },
  {
    id: "insect007",
    name: "Atlas Beetle",
    image: "https://example.com/images/atlas_beetle.jpg",
    habitat: "Tropical rainforests",
    behavior: "Nocturnal, males use horns in combat",
    description:
      "Atlas beetles are large with prominent horns, resembling their rhinoceros beetle cousins.",
    rarity: "epic",
  },
  {
    id: "insect008",
    name: "Bilberry Bumblebee",
    image: "https://example.com/images/bilberry_bumblebee.jpg",
    habitat: "Heathlands and moorlands",
    behavior: "Pollinates flowers, nests in small colonies",
    description:
      "Bilberry bumblebees are fuzzy pollinators favoring bilberry plants in cooler climates.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect009",
    name: "Black and Red Froghopper",
    image: "https://example.com/images/black_red_froghopper.jpg",
    habitat: "Grasslands and meadows",
    behavior: "Jumps to escape predators, produces foam nests",
    description:
      "Black and red froghoppers are small, colorful insects known for their leaping ability.",
    rarity: "common",
  },
  {
    id: "insect010",
    name: "Black Oil Beetle",
    image: "https://example.com/images/black_oil_beetle.jpg",
    habitat: "Grasslands and heathlands",
    behavior: "Parasitic, larvae hitch rides on bees",
    description:
      "Black oil beetles release oily secretions when threatened, with a shiny black body.",
    rarity: "rare",
  },
  {
    id: "insect011",
    name: "Bog Hoverfly",
    image: "https://example.com/images/bog_hoverfly.jpg",
    habitat: "Wetlands and bogs",
    behavior: "Hovers near flowers, mimics bees for protection",
    description:
      "Bog hoverflies are small flies with bee-like patterns, thriving in wet habitats.",
    rarity: "rare",
  },
  {
    id: "insect012",
    name: "Buffish Mining Bee",
    image: "https://example.com/images/buffish_mining_bee.jpg",
    habitat: "Gardens, meadows, and woodlands",
    behavior: "Solitary, digs nests in soil",
    description:
      "Buffish mining bees are solitary pollinators with a furry, buff-colored body.",
    rarity: "common",
  },
  {
    id: "insect013",
    name: "Cobweb Beetle",
    image: "https://example.com/images/cobweb_beetle.jpg",
    habitat: "Buildings and stored food areas",
    behavior: "Scavenges on debris, lives in dark corners",
    description:
      "Cobweb beetles are small pests often found in dusty, neglected areas indoors.",
    rarity: "common",
  },
  {
    id: "insect014",
    name: "Coastal Pearl",
    image: "https://example.com/images/coastal_pearl.jpg",
    habitat: "Coastal dunes and beaches",
    behavior: "Flies in sunny weather, feeds on nectar",
    description:
      "Coastal pearl butterflies are small, delicate insects of sandy coastal regions.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect015",
    name: "Dingy Skipper",
    image: "https://example.com/images/dingy_skipper.jpg",
    habitat: "Grasslands and chalk hills",
    behavior: "Fast flier, rests with wings spread",
    description:
      "Dingy skippers are small, moth-like butterflies with muted brown wings.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect016",
    name: "Dune Wolf Spider",
    image: "https://example.com/images/dune_wolf_spider.jpg",
    habitat: "Sandy dunes and coastal areas",
    behavior: "Hunts prey actively, does not spin webs",
    description:
      "Dune wolf spiders are ground-dwelling hunters with excellent vision.",
    rarity: "common",
  },
  {
    id: "insect017",
    name: "European Bee Wolf",
    image: "https://example.com/images/european_bee_wolf.jpg",
    habitat: "Sandy soils and grasslands",
    behavior: "Hunts bees to provision nests",
    description:
      "European bee wolves are solitary wasps that paralyze bees for their larvae.",
    rarity: "rare",
  },
  {
    id: "insect018",
    name: "Hobo Spider",
    image: "https://example.com/images/hobo_spider.jpg",
    habitat: "Buildings, gardens, and fields",
    behavior: "Builds funnel webs, nocturnal hunter",
    description:
      "Hobo spiders are fast-moving arachnids with a reputation for aggressive behavior.",
    rarity: "common",
  },
  {
    id: "insect019",
    name: "Landhopper",
    image: "https://example.com/images/landhopper.jpg",
    habitat: "Moist forests and gardens",
    behavior: "Jumps to move, thrives in damp soil",
    description:
      "Landhoppers are small crustaceans resembling insects, common in leaf litter.",
    rarity: "common",
  },
  {
    id: "insect020",
    name: "Lob Worm",
    image: "https://example.com/images/lob_worm.jpg",
    habitat: "Soils and compost heaps",
    behavior: "Burrows in soil, aids decomposition",
    description:
      "Lob worms are large earthworms vital for soil health and nutrient cycling.",
    rarity: "common",
  },
  {
    id: "insect021",
    name: "Mayfly",
    image: "https://example.com/images/mayfly.jpg",
    habitat: "Rivers, lakes, and streams",
    behavior: "Short-lived, swarms during mating",
    description:
      "Mayflies have delicate wings and a brief adult life, critical to aquatic ecosystems.",
    rarity: "common",
    seasonal: true,
  },
  {
    id: "insect022",
    name: "March Brown Mayfly",
    image: "https://example.com/images/march_brown_mayfly.jpg",
    habitat: "Fast-flowing rivers and streams",
    behavior: "Emerges in spring, short adult phase",
    description:
      "March brown mayflies are important for fish diets, with brown wings and slender bodies.",
    rarity: "common",
    seasonal: true,
  },
  {
    id: "insect023",
    name: "Millipedes",
    image: "https://example.com/images/millipedes.jpg",
    habitat: "Moist forests and gardens",
    behavior: "Detritivore, curls into a ball when threatened",
    description:
      "Millipedes are multi-legged creatures that feed on decaying plant matter.",
    rarity: "common",
  },
  {
    id: "insect024",
    name: "Northern Brown Argus",
    image: "https://example.com/images/northern_brown_argus.jpg",
    habitat: "Grasslands and heathlands",
    behavior: "Flies low, feeds on nectar",
    description:
      "Northern brown argus butterflies are small with brown wings and orange spots.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect025",
    name: "Orange Tip Butterfly",
    image: "https://example.com/images/orange_tip_butterfly.jpg",
    habitat: "Meadows, gardens, and woodlands",
    behavior: "Males display bright orange wingtips",
    description:
      "Orange tip butterflies are spring fliers with striking orange and white wings.",
    rarity: "common",
    seasonal: true,
  },
  {
    id: "insect026",
    name: "Northern Mining Bee",
    image: "https://example.com/images/northern_mining_bee.jpg",
    habitat: "Gardens and grasslands",
    behavior: "Solitary, nests in sandy soil",
    description:
      "Northern mining bees are small, furry pollinators active in early spring.",
    rarity: "common",
    seasonal: true,
  },
  {
    id: "insect027",
    name: "Pied Shieldbug",
    image: "https://example.com/images/pied_shieldbug.jpg",
    habitat: "Hedgerows and woodlands",
    behavior: "Herbivorous, feeds on plant sap",
    description:
      "Pied shieldbugs have a distinctive black and white pattern and a shield-shaped body.",
    rarity: "common",
  },
  {
    id: "insect028",
    name: "Peacock Spiders",
    image: "https://example.com/images/peacock_spiders.jpg",
    habitat: "Grasslands and shrublands",
    behavior: "Males perform colorful courtship dances",
    description:
      "Peacock spiders are tiny, vibrant arachnids known for their elaborate mating displays.",
    rarity: "epic",
  },
  {
    id: "insect029",
    name: "Ruby Tailed Wasp",
    image: "https://example.com/images/ruby_tailed_wasp.jpg",
    habitat: "Gardens and sunny habitats",
    behavior: "Parasitic, lays eggs in other insects’ nests",
    description:
      "Ruby tailed wasps are jewel-like with iridescent red and green bodies.",
    rarity: "rare",
  },
  {
    id: "insect030",
    name: "Scaly Cricket",
    image: "https://example.com/images/scaly_cricket.jpg",
    habitat: "Coastal cliffs and caves",
    behavior: "Nocturnal, wingless jumper",
    description:
      "Scaly crickets are rare, wingless insects adapted to dark, humid environments.",
    rarity: "rare",
  },
  {
    id: "insect031",
    name: "Sea Slater",
    image: "https://example.com/images/sea_slater.jpg",
    habitat: "Rocky shores and beaches",
    behavior: "Scavenges at night, hides under rocks",
    description:
      "Sea slaters are coastal crustaceans resembling woodlice, thriving in tidal zones.",
    rarity: "common",
  },
  {
    id: "insect032",
    name: "Small Blue",
    image: "https://example.com/images/small_blue.jpg",
    habitat: "Grasslands and coastal dunes",
    behavior: "Flies low, prefers kidney vetch plants",
    description:
      "Small blue butterflies are tiny with slate-blue wings, often overlooked.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect033",
    name: "Spiky Yellow Woodlouse",
    image: "https://example.com/images/spiky_yellow_woodlouse.jpg",
    habitat: "Moist woodlands and gardens",
    behavior: "Rolls into a ball for defense",
    description:
      "Spiky yellow woodlice are small crustaceans with a distinctive spiky appearance.",
    rarity: "common",
  },
  {
    id: "insect034",
    name: "Smooth Stick Insect",
    image: "https://example.com/images/smooth_stick_insect.jpg",
    habitat: "Forests and shrublands",
    behavior: "Camouflages as a twig, nocturnal feeder",
    description:
      "Smooth stick insects mimic twigs to avoid predators, with a slender, branch-like body.",
    rarity: "common",
  },
  {
    id: "insect035",
    name: "Tansy Beetle",
    image: "https://example.com/images/tansy_beetle.jpg",
    habitat: "Riverbanks and wetlands",
    behavior: "Herbivorous, feeds on tansy plants",
    description:
      "Tansy beetles are vibrant green beetles tied to tansy plants, now rare in some areas.",
    rarity: "rare",
  },
  {
    id: "insect036",
    name: "Water Measurer",
    image: "https://example.com/images/water_measurer.jpg",
    habitat: "Ponds and slow-moving waters",
    behavior: "Walks on water surface, preys on small insects",
    description:
      "Water measurers are slender bugs that skate on water to hunt tiny prey.",
    rarity: "common",
  },
  {
    id: "insect037",
    name: "Migrant Hawker Dragonfly",
    image: "https://example.com/images/migrant_hawker_dragonfly.jpg",
    habitat: "Ponds, lakes, and canals",
    behavior: "Fast flier, hawks for insect prey",
    description:
      "Migrant hawker dragonflies are agile fliers with blue-spotted abdomens.",
    rarity: "common",
    seasonal: true,
  },
  {
    id: "insect038",
    name: "Wasp Spider",
    image: "https://example.com/images/wasp_spider.jpg",
    habitat: "Grasslands and meadows",
    behavior: "Builds wheel-shaped webs, mimics wasps",
    description:
      "Wasp spiders have yellow and black stripes, resembling wasps to deter predators.",
    rarity: "rare",
  },
  {
    id: "insect039",
    name: "Ladybird Spider",
    image: "https://example.com/images/ladybird_spider.jpg",
    habitat: "Heathlands and dry grasslands",
    behavior: "Males are brightly colored, females are larger",
    description:
      "Ladybird spiders are rare, with males displaying vivid red and black patterns.",
    rarity: "epic",
  },
  {
    id: "insect040",
    name: "Large Conehead",
    image: "https://example.com/images/large_conehead.jpg",
    habitat: "Grasslands and marshes",
    behavior: "Stridulates to attract mates",
    description:
      "Large coneheads are grasshoppers with conical heads, known for their loud songs.",
    rarity: "common",
  },
  {
    id: "insect041",
    name: "Ivy Plasterer Bee",
    image: "https://example.com/images/ivy_plasterer_bee.jpg",
    habitat: "Gardens and woodlands",
    behavior: "Solitary, nests in crevices",
    description:
      "Ivy plasterer bees are small pollinators that favor ivy flowers in autumn.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect042",
    name: "Great Yellow Bumblebee",
    image: "https://example.com/images/great_yellow_bumblebee.jpg",
    habitat: "Coastal grasslands and machair",
    behavior: "Pollinates wildflowers, nests in burrows",
    description:
      "Great yellow bumblebees are rare, vibrant pollinators of northern regions.",
    rarity: "epic",
  },
  {
    id: "insect043",
    name: "Eyed Longhorn Beetle",
    image: "https://example.com/images/eyed_longhorn_beetle.jpg",
    habitat: "Woodlands and forests",
    behavior: "Larvae bore into wood, adults feed on pollen",
    description:
      "Eyed longhorn beetles have long antennae and eye-like spots on their wings.",
    rarity: "rare",
  },
  {
    id: "insect044",
    name: "Red Mason Bee",
    image: "https://example.com/images/red_mason_bee.jpg",
    habitat: "Gardens and woodlands",
    behavior: "Solitary, nests in cavities",
    description:
      "Red mason bees are excellent pollinators, using mud to seal their nests.",
    rarity: "common",
  },
  {
    id: "insect045",
    name: "Elephant Hawk Moth",
    image: "https://example.com/images/elephant_hawk_moth.jpg",
    habitat: "Gardens and woodlands",
    behavior: "Nocturnal, feeds on nectar",
    description:
      "Elephant hawk moths have striking pink and olive wings, named for their caterpillar’s shape.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect046",
    name: "Glow Worm",
    image: "https://example.com/images/glow_worm.jpg",
    habitat: "Grasslands and woodlands",
    behavior: "Females glow to attract males",
    description:
      "Glow worms are beetles whose females emit light to signal mates at night.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect047",
    name: "Green Dock Beetle",
    image: "https://example.com/images/green_dock_beetle.jpg",
    habitat: "Meadows and gardens",
    behavior: "Herbivorous, feeds on dock plants",
    description:
      "Green dock beetles are shiny, metallic beetles tied to dock and sorrel plants.",
    rarity: "common",
  },
  {
    id: "insect048",
    name: "Common Red Soldier Beetle",
    image: "https://example.com/images/red_soldier_beetle.jpg",
    habitat: "Meadows and gardens",
    behavior: "Predatory, feeds on smaller insects",
    description:
      "Common red soldier beetles are bright red and often seen on flowers.",
    rarity: "common",
    seasonal: true,
  },
  {
    id: "insect049",
    name: "Violet Ground Beetle",
    image: "https://example.com/images/violet_ground_beetle.jpg",
    habitat: "Woodlands and gardens",
    behavior: "Nocturnal predator, hunts slugs",
    description:
      "Violet ground beetles are fast-moving predators with a shiny, violet-black body.",
    rarity: "common",
  },
  {
    id: "insect050",
    name: "Cuckoo Bee",
    image: "https://example.com/images/cuckoo_bee.jpg",
    habitat: "Meadows and gardens",
    behavior: "Parasitic, lays eggs in other bees’ nests",
    description:
      "Cuckoo bees mimic host bees to infiltrate nests, lacking pollen-collecting structures.",
    rarity: "rare",
  },
  {
    id: "insect051",
    name: "Wood Ant",
    image: "https://example.com/images/wood_ant.jpg",
    habitat: "Forests and woodlands",
    behavior: "Builds large nests, defends with formic acid",
    description:
      "Wood ants are social insects that create massive nests and farm aphids.",
    rarity: "common",
  },
  {
    id: "insect052",
    name: "Ichneumon Wasp",
    image: "https://example.com/images/ichneumon_wasp.jpg",
    habitat: "Forests and grasslands",
    behavior: "Parasitoid, lays eggs in other insects",
    description:
      "Ichneumon wasps are slender parasitoids with long ovipositors for egg-laying.",
    rarity: "common",
  },
  {
    id: "insect053",
    name: "Blue Morpho Butterfly",
    image: "https://example.com/images/blue_morpho_butterfly.jpg",
    habitat: "Tropical rainforests",
    behavior: "Flies in canopy, flashes iridescent wings",
    description:
      "Blue morpho butterflies are known for their dazzling blue wings that shimmer in sunlight.",
    rarity: "epic",
  },
  {
    id: "insect054",
    name: "Darkling Beetle",
    image: "https://example.com/images/darkling_beetle.jpg",
    habitat: "Deserts and forests",
    behavior: "Scavenges on decaying matter",
    description:
      "Darkling beetles are hardy insects that thrive in harsh, dry environments.",
    rarity: "common",
  },
  {
    id: "insect055",
    name: "Fire Ant",
    image: "https://example.com/images/fire_ant.jpg",
    habitat: "Grasslands and urban areas",
    behavior: "Aggressive, delivers painful stings",
    description:
      "Fire ants are invasive, forming large colonies with a fiery sting.",
    rarity: "common",
  },
  {
    id: "insect056",
    name: "Kissing Bug",
    image: "https://example.com/images/kissing_bug.jpg",
    habitat: "Warm climates, near human dwellings",
    behavior: "Nocturnal, feeds on blood",
    description:
      "Kissing bugs are blood-sucking insects that can transmit Chagas disease.",
    rarity: "rare",
  },
  {
    id: "insect057",
    name: "Spiny Flower Mantis",
    image: "https://example.com/images/spiny_flower_mantis.jpg",
    habitat: "Tropical forests",
    behavior: "Mimics flowers to ambush prey",
    description:
      "Spiny flower mantises use vibrant camouflage to blend into flowers.",
    rarity: "epic",
  },
  {
    id: "insect058",
    name: "Zebra Swallowtail Butterfly",
    image: "https://example.com/images/zebra_swallowtail_butterfly.jpg",
    habitat: "Woodlands and river edges",
    behavior: "Flies swiftly, feeds on nectar",
    description:
      "Zebra swallowtail butterflies have striking black and white striped wings.",
    rarity: "rare",
    seasonal: true,
  },
  {
    id: "insect059",
    name: "Dung Beetle",
    image: "https://example.com/images/dung_beetle.jpg",
    habitat: "Grasslands and forests",
    behavior: "Rolls dung into balls for food and breeding",
    description:
      "Dung beetles are vital recyclers, using dung for nourishment and reproduction.",
    rarity: "common",
  },
  {
    id: "insect060",
    name: "Praying Mantids",
    image: "https://example.com/images/praying_mantids.jpg",
    habitat: "Shrubs, trees, and grasslands",
    behavior: "Ambush predator, uses camouflage",
    description:
      "Praying mantids are known for their upright posture and rapid hunting strikes.",
    rarity: "common",
  },
  {
    id: "insect061",
    name: "Sawflies",
    image: "https://example.com/images/sawflies.jpg",
    habitat: "Forests and gardens",
    behavior: "Larvae feed on leaves, adults are short-lived",
    description:
      "Sawflies resemble wasps, with larvae that can defoliate plants.",
    rarity: "common",
  },
  {
    id: "insect062",
    name: "Firebrat",
    image: "https://example.com/images/firebrat.jpg",
    habitat: "Warm indoor areas",
    behavior: "Scavenges on starchy materials",
    description:
      "Firebrats are small, silvery insects that thrive in hot, humid environments.",
    rarity: "common",
  },
  {
    id: "insect063",
    name: "Caddisflies",
    image: "https://example.com/images/caddisflies.jpg",
    habitat: "Rivers, streams, and lakes",
    behavior: "Larvae build protective cases, adults are short-lived",
    description:
      "Caddisflies are moth-like insects with aquatic larvae that construct cases from debris.",
    rarity: "common",
    seasonal: true,
  },
];
